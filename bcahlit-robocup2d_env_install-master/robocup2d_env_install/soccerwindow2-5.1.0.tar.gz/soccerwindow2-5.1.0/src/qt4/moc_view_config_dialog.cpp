/****************************************************************************
** Meta object code from reading C++ file 'view_config_dialog.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "view_config_dialog.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'view_config_dialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ViewConfigDialog[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
     106,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      18,   17,   17,   17, 0x05,
      36,   31,   17,   17, 0x05,

 // slots: signature, parameters, type, tag, flags
      57,   17,   17,   17, 0x08,
      77,   69,   17,   17, 0x08,
     102,   96,   17,   17, 0x08,
     123,   17,   17,   17, 0x08,
     147,   69,   17,   17, 0x08,
     170,   69,   17,   17, 0x08,
     199,   69,   17,   17, 0x08,
     227,   69,   17,   17, 0x08,
     253,   69,   17,   17, 0x08,
     276,   69,   17,   17, 0x08,
     307,   69,   17,   17, 0x08,
     331,   69,   17,   17, 0x08,
     357,   69,   17,   17, 0x08,
     386,   69,   17,   17, 0x08,
     412,   69,   17,   17, 0x08,
     441,   69,   17,   17, 0x08,
     464,   69,   17,   17, 0x08,
     491,   69,   17,   17, 0x08,
     511,   69,   17,   17, 0x08,
     536,   69,   17,   17, 0x08,
     562,   69,   17,   17, 0x08,
     589,   69,   17,   17, 0x08,
     609,   69,   17,   17, 0x08,
     632,   69,   17,   17, 0x08,
     653,   69,   17,   17, 0x08,
     680,   17,   17,   17, 0x08,
     699,   17,   17,   17, 0x08,
     716,   17,   17,   17, 0x08,
     736,   69,   17,   17, 0x08,
     760,   69,   17,   17, 0x08,
     785,   96,   17,   17, 0x08,
     809,  804,   17,   17, 0x08,
     837,  831,   17,   17, 0x08,
     857,   69,   17,   17, 0x08,
     879,   69,   17,   17, 0x08,
     903,   69,   17,   17, 0x08,
     923,   69,   17,   17, 0x08,
     953,   69,   17,   17, 0x08,
     990,  831,   17,   17, 0x08,
    1014,   17,   17,   17, 0x08,
    1031,   17,   17,   17, 0x08,
    1050,   17,   17,   17, 0x08,
    1071,   17,   17,   17, 0x08,
    1093,   17,   17,   17, 0x08,
    1116,   17,   17,   17, 0x08,
    1140, 1133,   17,   17, 0x08,
    1157, 1133,   17,   17, 0x08,
    1174,  804,   17,   17, 0x08,
    1202,  804,   17,   17, 0x08,
    1228,   17,   17,   17, 0x08,
    1248,   69,   17,   17, 0x08,
    1273,  804,   17,   17, 0x08,
    1303,  804,   17,   17, 0x08,
    1331,   17,   17,   17, 0x08,
    1353,   69,   17,   17, 0x08,
    1380,  804,   17,   17, 0x08,
    1408,   96,   17,   17, 0x08,
    1435,   17,   17,   17, 0x08,
    1458,   96,   17,   17, 0x08,
    1485,   96,   17,   17, 0x08,
    1514,  831,   17,   17, 0x08,
    1542,   96,   17,   17, 0x08,
    1580,   17,   17,   17, 0x0a,
    1599,   17,   17,   17, 0x0a,
    1608,   17,   17,   17, 0x0a,
    1618,   17,   17,   17, 0x0a,
    1632,   17,   17,   17, 0x0a,
    1648,  804,   17,   17, 0x0a,
    1670,  804,   17,   17, 0x0a,
    1694,   17,   17,   17, 0x0a,
    1712,   17,   17,   17, 0x0a,
    1732,   17,   17,   17, 0x0a,
    1758,   17,   17,   17, 0x0a,
    1783,   17,   17,   17, 0x0a,
    1806,   17,   17,   17, 0x0a,
    1826,   17,   17,   17, 0x0a,
    1854,   17,   17,   17, 0x0a,
    1875,   17,   17,   17, 0x0a,
    1898,   17,   17,   17, 0x0a,
    1924,   17,   17,   17, 0x0a,
    1947,   17,   17,   17, 0x0a,
    1973,   17,   17,   17, 0x0a,
    1993,   17,   17,   17, 0x0a,
    2017,   17,   17,   17, 0x0a,
    2034,   17,   17,   17, 0x0a,
    2056,   17,   17,   17, 0x0a,
    2079,   17,   17,   17, 0x0a,
    2103,   17,   17,   17, 0x0a,
    2123,   17,   17,   17, 0x0a,
    2140,   17,   17,   17, 0x0a,
    2158,   17,   17,   17, 0x0a,
    2182,   17,   17,   17, 0x0a,
    2200,   17,   17,   17, 0x0a,
    2220,   17,   17,   17, 0x0a,
    2240, 2234,   17,   17, 0x0a,
    2262,   17,   17,   17, 0x0a,
    2284,   17,   17,   17, 0x0a,
    2307,   17,   17,   17, 0x0a,
    2331,   17,   17,   17, 0x0a,
    2349,   17,   17,   17, 0x0a,
    2363,   17,   17,   17, 0x0a,
    2384,   17,   17,   17, 0x0a,
    2402,   17,   17,   17, 0x0a,
    2421,   17,   17,   17, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ViewConfigDialog[] = {
    "ViewConfigDialog\0\0configured()\0size\0"
    "canvasResized(QSize)\0updateAll()\0"
    "checked\0clickEnlarge(bool)\0value\0"
    "slideFieldScale(int)\0editFieldScale(QString)\0"
    "clickReverseSide(bool)\0"
    "clickPlayerReverseDraw(bool)\0"
    "clickShowPlayerNumber(bool)\0"
    "clickShowPlayerType(bool)\0"
    "clickShowStamina(bool)\0"
    "clickShowStaminaCapacity(bool)\0"
    "clickShowViewArea(bool)\0"
    "clickShowBodyShadow(bool)\0"
    "clickShowCatchableArea(bool)\0"
    "clickShowTackleArea(bool)\0"
    "clickShowKickAccelArea(bool)\0"
    "clickShowPointto(bool)\0"
    "clickShowAttentionto(bool)\0"
    "clickShowCard(bool)\0clickAnonymousMode(bool)\0"
    "clickShowScoreBoard(bool)\0"
    "clickShowTeamGraphic(bool)\0"
    "clickShowBall(bool)\0clickShowPlayers(bool)\0"
    "clickShowFlags(bool)\0clickShowOffsideLine(bool)\0"
    "clickGrassNormal()\0clickGrassLine()\0"
    "clickGrassChecker()\0clickKeepawayMode(bool)\0"
    "clickShowGridCoord(bool)\0slideGridStep(int)\0"
    "text\0editGridStep(QString)\0index\0"
    "selectDrawType(int)\0clickCursorHide(bool)\0"
    "clickAntiAliasing(bool)\0clickGradient(bool)\0"
    "clickShowVoronoiDiagram(bool)\0"
    "clickShowDelaunayTriangulation(bool)\0"
    "selectCompGeomSide(int)\0clickFocusBall()\0"
    "clickFocusPlayer()\0clickSelectAutoAll()\0"
    "clickSelectAutoLeft()\0clickSelectAutoRight()\0"
    "clickSelectFix()\0number\0selectAgent(int)\0"
    "choiceAgent(int)\0editBallTraceStart(QString)\0"
    "editBallTraceEnd(QString)\0clickBallTraceAll()\0"
    "clickAutoBallTrace(bool)\0"
    "editPlayerTraceStart(QString)\0"
    "editPlayerTraceEnd(QString)\0"
    "clickPlayerTraceAll()\0clickAutoPlayerTrace(bool)\0"
    "editAutoTraceStart(QString)\0"
    "changeAutoTracePeriod(int)\0"
    "clickLinePointButton()\0"
    "changeBallFutureCycle(int)\0"
    "changePlayerFutureCycle(int)\0"
    "selectMouseMeasureMode(int)\0"
    "changeMouseMeasureFirstLength(double)\0"
    "updateFieldScale()\0zoomIn()\0zoomOut()\0"
    "fitToScreen()\0toggleEnlarge()\0"
    "editBallSize(QString)\0editPlayerSize(QString)\0"
    "applyCanvasSize()\0toggleReverseSide()\0"
    "togglePlayerReverseDraw()\0"
    "toggleShowPlayerNumber()\0"
    "toggleShowPlayerType()\0toggleShowStamina()\0"
    "toggleShowStaminaCapacity()\0"
    "toggleShowViewArea()\0toggleShowBodyShadow()\0"
    "toggleShowCatchableArea()\0"
    "toggleShowTackleArea()\0toggleShowKickAccelArea()\0"
    "toggleShowPointto()\0toggleShowAttentionto()\0"
    "toggleShowCard()\0toggleAnonymousMode()\0"
    "toggleShowScoreBoard()\0toggleShowTeamGraphic()\0"
    "toggleShowPlayers()\0toggleShowBall()\0"
    "toggleShowFlags()\0toggleShowOffsideLine()\0"
    "toggleFocusBall()\0toggleFocusPlayer()\0"
    "setFocusFix()\0point\0setFocusPoint(QPoint)\0"
    "toggleSelectAutoAll()\0toggleSelectAutoLeft()\0"
    "toggleSelectAutoRight()\0toggleSelectFix()\0"
    "setUnselect()\0selectAgentWithKey()\0"
    "selectLeftCoach()\0selectRightCoach()\0"
    "toggleKeepawayMode()\0"
};

void ViewConfigDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ViewConfigDialog *_t = static_cast<ViewConfigDialog *>(_o);
        switch (_id) {
        case 0: _t->configured(); break;
        case 1: _t->canvasResized((*reinterpret_cast< const QSize(*)>(_a[1]))); break;
        case 2: _t->updateAll(); break;
        case 3: _t->clickEnlarge((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->slideFieldScale((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->editFieldScale((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: _t->clickReverseSide((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->clickPlayerReverseDraw((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->clickShowPlayerNumber((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->clickShowPlayerType((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->clickShowStamina((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->clickShowStaminaCapacity((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->clickShowViewArea((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->clickShowBodyShadow((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: _t->clickShowCatchableArea((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 15: _t->clickShowTackleArea((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 16: _t->clickShowKickAccelArea((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 17: _t->clickShowPointto((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: _t->clickShowAttentionto((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 19: _t->clickShowCard((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 20: _t->clickAnonymousMode((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 21: _t->clickShowScoreBoard((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 22: _t->clickShowTeamGraphic((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 23: _t->clickShowBall((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 24: _t->clickShowPlayers((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 25: _t->clickShowFlags((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: _t->clickShowOffsideLine((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 27: _t->clickGrassNormal(); break;
        case 28: _t->clickGrassLine(); break;
        case 29: _t->clickGrassChecker(); break;
        case 30: _t->clickKeepawayMode((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 31: _t->clickShowGridCoord((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 32: _t->slideGridStep((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 33: _t->editGridStep((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 34: _t->selectDrawType((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 35: _t->clickCursorHide((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 36: _t->clickAntiAliasing((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 37: _t->clickGradient((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 38: _t->clickShowVoronoiDiagram((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 39: _t->clickShowDelaunayTriangulation((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 40: _t->selectCompGeomSide((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 41: _t->clickFocusBall(); break;
        case 42: _t->clickFocusPlayer(); break;
        case 43: _t->clickSelectAutoAll(); break;
        case 44: _t->clickSelectAutoLeft(); break;
        case 45: _t->clickSelectAutoRight(); break;
        case 46: _t->clickSelectFix(); break;
        case 47: _t->selectAgent((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 48: _t->choiceAgent((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 49: _t->editBallTraceStart((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 50: _t->editBallTraceEnd((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 51: _t->clickBallTraceAll(); break;
        case 52: _t->clickAutoBallTrace((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 53: _t->editPlayerTraceStart((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 54: _t->editPlayerTraceEnd((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 55: _t->clickPlayerTraceAll(); break;
        case 56: _t->clickAutoPlayerTrace((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 57: _t->editAutoTraceStart((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 58: _t->changeAutoTracePeriod((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 59: _t->clickLinePointButton(); break;
        case 60: _t->changeBallFutureCycle((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 61: _t->changePlayerFutureCycle((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 62: _t->selectMouseMeasureMode((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 63: _t->changeMouseMeasureFirstLength((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 64: _t->updateFieldScale(); break;
        case 65: _t->zoomIn(); break;
        case 66: _t->zoomOut(); break;
        case 67: _t->fitToScreen(); break;
        case 68: _t->toggleEnlarge(); break;
        case 69: _t->editBallSize((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 70: _t->editPlayerSize((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 71: _t->applyCanvasSize(); break;
        case 72: _t->toggleReverseSide(); break;
        case 73: _t->togglePlayerReverseDraw(); break;
        case 74: _t->toggleShowPlayerNumber(); break;
        case 75: _t->toggleShowPlayerType(); break;
        case 76: _t->toggleShowStamina(); break;
        case 77: _t->toggleShowStaminaCapacity(); break;
        case 78: _t->toggleShowViewArea(); break;
        case 79: _t->toggleShowBodyShadow(); break;
        case 80: _t->toggleShowCatchableArea(); break;
        case 81: _t->toggleShowTackleArea(); break;
        case 82: _t->toggleShowKickAccelArea(); break;
        case 83: _t->toggleShowPointto(); break;
        case 84: _t->toggleShowAttentionto(); break;
        case 85: _t->toggleShowCard(); break;
        case 86: _t->toggleAnonymousMode(); break;
        case 87: _t->toggleShowScoreBoard(); break;
        case 88: _t->toggleShowTeamGraphic(); break;
        case 89: _t->toggleShowPlayers(); break;
        case 90: _t->toggleShowBall(); break;
        case 91: _t->toggleShowFlags(); break;
        case 92: _t->toggleShowOffsideLine(); break;
        case 93: _t->toggleFocusBall(); break;
        case 94: _t->toggleFocusPlayer(); break;
        case 95: _t->setFocusFix(); break;
        case 96: _t->setFocusPoint((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 97: _t->toggleSelectAutoAll(); break;
        case 98: _t->toggleSelectAutoLeft(); break;
        case 99: _t->toggleSelectAutoRight(); break;
        case 100: _t->toggleSelectFix(); break;
        case 101: _t->setUnselect(); break;
        case 102: _t->selectAgentWithKey(); break;
        case 103: _t->selectLeftCoach(); break;
        case 104: _t->selectRightCoach(); break;
        case 105: _t->toggleKeepawayMode(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData ViewConfigDialog::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ViewConfigDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_ViewConfigDialog,
      qt_meta_data_ViewConfigDialog, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ViewConfigDialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ViewConfigDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ViewConfigDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ViewConfigDialog))
        return static_cast<void*>(const_cast< ViewConfigDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int ViewConfigDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 106)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 106;
    }
    return _id;
}

// SIGNAL 0
void ViewConfigDialog::configured()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void ViewConfigDialog::canvasResized(const QSize & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE
